//package com.example.android.cinemax.cinemax;
//
//import android.app.Fragment;
//import android.support.v7.app.AppCompatActivity;
//import android.os.Bundle;
//import android.view.View;
//import android.view.ViewGroup;
//
//public class ViewPagerActivity extends Fragment {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_view_pager);
//
//        @Override
//        public View onCreateView(LayoutInflater inflater, ViewGroup container,
//                Bundle savedInstanceState) {
//            ViewGroup rootView = (ViewGroup) inflater.inflate(
//                    R.layout.fragment_screen_slide_page, container, false);
//
//            return rootView;
//        }
//    }
//    }
//}
