package com.bootcamp.xsis.keta;

import android.app.Activity;

/**
 * Created by Jack Ma on 1/21/2018.
 */

public class slider extends Activity {
}
