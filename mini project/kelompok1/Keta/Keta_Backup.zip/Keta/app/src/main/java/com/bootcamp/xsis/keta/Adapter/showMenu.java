package com.bootcamp.xsis.keta.Adapter;

/**
 * Created by Jack Ma on 1/17/2018.
 */

public class showMenu {

    private int _id;
    private String id_product;
    private String nama_produk;
    private String gambar_produk;
    private String desk_produk;
    private String id_kategori_produk;
    private int harga_produk;


    private int id_user;
    private String nama_user;
    private String phoneNumber;
    private String pas_user;

    private String kategorii_produk;
    private int Quantity;
    private int subtotal;
    private int totalAkhir;
    private int totalAkhirBaru;

    private String alamat;
    private String atm;
    private String kode_pesanan;


    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getNama_produk() {
        return nama_produk;
    }

    public void setNama_produk(String nama_produk) {
        this.nama_produk = nama_produk;
    }

    public String getGambar_produk() {
        return gambar_produk;
    }

    public void setGambar_produk(String gambar_produk) {
        this.gambar_produk = gambar_produk;
    }

    public String getDesk_produk() {
        return desk_produk;
    }

    public void setDesk_produk(String desk_produk) {
        this.desk_produk = desk_produk;
    }

    public String getId_kategori_produk() {
        return id_kategori_produk;
    }

    public void setId_kategori_produk(String id_kategori_produk) {
        this.id_kategori_produk = id_kategori_produk;
    }

    public int getHarga_produk() {
        return harga_produk;
    }

    public void setHarga_produk(int harga_produk) {
        this.harga_produk = harga_produk;
    }

    public String getId_product() {
        return id_product;
    }

    public void setId_product(String id_product) {
        this.id_product = id_product;
    }

    public int getId_user() {
        return id_user;
    }

    public void setId_user(int id_user) {
        this.id_user = id_user;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPas_user() {
        return pas_user;
    }

    public void setPas_user(String pas_user) {
        this.pas_user = pas_user;
    }

    public String getKategorii_produk() {
        return kategorii_produk;
    }

    public void setKategorii_produk(String kategorii_produk) {
        this.kategorii_produk = kategorii_produk;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int quantity) {
        Quantity = quantity;
    }

    public int getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(int subtotal) {
        this.subtotal = subtotal;
    }

    public int getTotalAkhir() {
        return totalAkhir;
    }

    public void setTotalAkhir(int totalAkhir) {
        this.totalAkhir = totalAkhir;
    }


    public int getTotalAkhirBaru() {
        return totalAkhirBaru;
    }

    public void setTotalAkhirBaru(int totalAkhirBaru) {
        this.totalAkhirBaru = totalAkhirBaru;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getAtm() {
        return atm;
    }

    public void setAtm(String atm) {
        this.atm = atm;
    }

    public String getNama_user() {
        return nama_user;
    }

    public void setNama_user(String nama_user) {
        this.nama_user = nama_user;
    }

    public String getKode_pesanan() {
        return kode_pesanan;
    }

    public void setKode_pesanan(String kode_pesanan) {
        this.kode_pesanan = kode_pesanan;
    }
}
